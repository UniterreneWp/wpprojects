<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       themeszone-add-vc-shortcodes
 * @since      1.0.0
 *
 * @package    Themeszone_Add_Vc_Shortcodes
 * @subpackage Themeszone_Add_Vc_Shortcodes/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
