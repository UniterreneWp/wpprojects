=== ThemesZone Add Visual Composer Shortcodes ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: themeszone-add-vc-shortcodes
Tags: comments, spam
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Here is a short description of the plugin.  This should be no more than 150 characters.  No markup here.

== Description ==

This plugin adds custom elements for Visual Composer plugin.


Feel free to ask any questions at <a href="https://themes.zone">Themes Zone</a>

== Installation ==

1. Upload `themeszone-add-vc-shortcodes` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Changelog ==

= 1.0 =
* Initial Release.

